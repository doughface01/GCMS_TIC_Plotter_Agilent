# -*- coding: utf-8 -*-
"""
To do (for Matt's benefit!). If you need anything changed,
or encounter bugs, issues, contact me at: mxa415@student.bham.ac.uk
    - Add more styling options
    - Check it works on a MAC

////////////////////////////////////////////////
//              GC-MS TIC Plotter             //
////////////////////////////////////////////////

This code will take a one or more Agilent GC-MS files
and plot up the TIC (Total Ion Chromatogram) traces
in a consistent and formatable manner.

I'm aware users of this code might not be used to coding
so will try to comment with instructions as much as 
possible.

For reference, this code was written and tested in 
a Windows/Ubuntu operating system. I will try my best 
to support MAC based workflows.

The outputs of the code will dump into the Image_Dump folder 
next to where the code runs. Inside are two further folders,
SVG and JPEG. JPEG is a .jpg file of the export, whereas
in .svg you will find the graph saved as a vector graphic. 
This can be opened in Illustrator, Inkscape etc. as an 
editable vector graphic (very useful!).

"""
#%% Modules and Error Messages
"""
////////////////////////////////////////////////
//                   Modules                  //
///////////////////////////////////////////////

This code is dependent on a selection of modules
which provide useful functionality. Some modules
might need installing outside of this script before
you can use them. If so google:
    
    "install (module name) anaconda windows/MAC"

"""

print("Installing packages...")

import os
import sys
import subprocess

# List of packages that might need intalling
package = ["tk",
           "numpy",
           "pandas",
           "matplotlib",
           "glob2"]

reqs = subprocess.check_output([sys.executable, '-m', 'pip', 'freeze'])
installed_packages = [r.decode().split('==')[0] for r in reqs.split()]

needs_installing = []

for i in package:   
    if i in installed_packages:
        pass
    else: 
         needs_installing.append(i)
         
if needs_installing == []:
    print("Packages installed correctly, moving on...")
else:
    string = f"The following packages need installing: {needs_installing}"
    print(string)
            
from tkinter import messagebox
import numpy as np
import pandas as pd
import matplotlib.pyplot as pyplot
from glob2 import glob

print("Package installation complete")

"""

////////////////////////////////////////////////
//              Error Messages               //
///////////////////////////////////////////////

This section provides a list of error messages.
Hopefully you will never see these, but in case you do
they will prompt you as to where the issue is.


"""

err_msg_1 = "Data folder not found/inaccessible, please check value of data"
err_msg_2 = "Incorrectly entered mode of operation, check mode = one of the lists in data selection"

#%% User Input
"""

////////////////////////////////////////////////
//                User Input                 //
///////////////////////////////////////////////

Below are all the bits you will need to fiddle with to
get the desired output.

"""

# Name of the data folder to be investigated. Input the name between the
# quotation marks. This folder needs to house all the files/folders that
# get spat out of the GCMS. Please ensure all data is saved within one folder
# instide the Data_dump folder.

data = "Example Dataset"

"""

////////////////////////////////////////////////
//              Operating Modes               //
///////////////////////////////////////////////

The code works requires you to instruct it as to
what data you want to analyse. There are three modes
of operation:
    - Single-file analysis: 
        - Grabs a single GCMS file and plots the TIC.
    - Multi-file analysis:
        - Grabs a user provided selection of GCMS files
          and plots the TIC files.
    - All-file analysis:
        - Works like multi-file, but for everythin in a 
          folder.
         
Note: For all lists below the format is as follows: 
    - 1st row: Name of the group which becomes the graph 
               and file names for the exported graphs
    - 2nd - nth row: Names of the data files

"""

print("Creating list of data folders...")

Single_File = ["Example Dataset Single Plot",
               "3637 Si F2.D"]

Multi_File_n = ["--- Graph title ---",
                "--- File name 1---",
                "--- File name 2---",
                "--- File name 3---",
                "--- File name 4---",
                "--- File name 5---",
                "--- File name 6---",
                "--- File name etc. ---"]

Multi_File_Example = ["Example Dataset Multi Plot",
                      "3637 Si F2.D",
                      "3638 Si F2.D",
                      "3639 Si F2.D",
                      "3640 Si F2.D",
                      "3641 Si F2.D",
                      "3642 Si F2.D",
                      "3643 Si F2.D",
                      "3644 Si F2.D"]

All_Files = ["All Files Example"]
  
"""

Select the operating mode:
    - Single-file:  mode = Single_File
    - Multi-file:   mode = Multi_File_n
    - All-file:     mode = All_Files
    
Select if you wish to see abundances plotted in terms of 
relative or absolute abundance. 
    - Relative: 100% abundance will be scaled to the maximum
                abundance within that single sample.
    - Absolute: 100% abundance will be scaled to the maximum 
                abundance within the group of files being 
                analysed (i.e. max within the files listed within
                a multi-file list or all-file list)

"""

try:
    mode = Multi_File_Example
except:
    messagebox.showerror("error",err_msg_2)

relative = True
absolute = False

#%% Graph Styling
"""

////////////////////////////////////////////////
//                Graph Styling              //
///////////////////////////////////////////////

The package used to plot the data is called Matplotlib. It is
very flexible and has endless options. Below are a selection of 
commonly used plotting options that you can play around with. 

"""

# Define the base size of one plot (multi plots scale with this base unit)
figure_width = 15
figure_height = 5

# Defines the graph title (first row on the lists in Data Selection)
graph_title = f"{mode[0]}"
# Choose graph title size
graph_title_fontsize = 30
graph_title_y_position = 1.0

# Line styling options for the TIC plots
line_style = "-"
line_colour = "blue"
line_width = 1

# Choose your y-axis styling options
y_axis_label = "Abundance [%]"
y_axis_label_fontsize = 20
y_axis_lower_limit = 0
y_axis_upper_limit = 100

# If you wish all plots to have an x-axis numberline then = True
# If you wish only the bottom graph to have x-axis numberline then = False
x_axis_numberline = True

# Choose you x-axis styling options
x_axis_label = "Retention Time [min]"
x_axis_label_fontsize = 20
# Don't touch the line below! Thanks :)
x_axis_tick_labels = []

# Choose fontisze for the axes numberlines
tick_label_fontsize = 20

# Subplot label details, position of label and also the size
# The subplot label will be the name of the TIC file
subplot_title_x_position = 0.2
subplot_title_y_position = 1
subplot_title_pad = -20
subplot_title_fontsize = 20

#%% Housekeeping and Code
"""

////////////////////////////////////////////////
//              Housekeeping                 //
///////////////////////////////////////////////

This section provides the code with some sense of where
it is installed and where to go looking for datafiles etc.

You will have downloaded this code from GitHub. It will 
need to be saved to a desired location and unzipped.
Inside the zipped folder you will find the following:
    
    - Parent folder: Folder that houses everything
    - Image_dump: Folder where all outputs are saved to
    - Data_dump: Folder that houses the GCMS data
    - Code: The thing you are reading right now!


"""

print("Getting directory information...")
# Grabs the directory for where you have saved the code, make sure 
# that the python script is executing from within that folder
  
code_dr = os.path.dirname(__file__)
os.chdir(code_dr)


# Locates and nicknames the image dump folder
image_dump = f"{code_dr}/Image_Dump"
data_dump = f"{code_dr}/Data_Dump"

folder_check = []
# Checks that you have selected an actual folder
temp = glob(f"{data_dump}/*/", recursive = True)
front_strip = len(f"{data_dump}")
for i in temp:
    i = i[(front_strip+1):]
    i = i[:-1]
    folder_check.append(i)

if data in folder_check:
    print("Data folder found")
else:
    messagebox.showerror("error", err_msg_1)

# Sort out All_Files Directory
# Code that sorts through the list of all folders within the data directory 
# and provides a list of all file names to iterater through
temp = glob(f"{data_dump}/Example Dataset/*/", recursive = True)

front_strip = len(f"{data_dump}/Example Dataset")

# Strips characters to leave only the filename of interest and saves to All_Files
for i in temp:
    i = i[(front_strip+1):]
    i = i[:-1]
    All_Files.append(i)
 
# Calculates the size of the list chosen for graphing
size = len(mode)

"""

////////////////////////////////////////////////
//                Graph Plotting             //
///////////////////////////////////////////////

Below is the actual code. It works by looping through whatever list
"mode" is set to. It takes the first line of that list as the graph 
title. As the loop progresses, TIC files are located, plotted and 
formatted (as specified above).

Feel free to dick around with this!

"""
print("Plotting graphs...")

# Calculates the size of a multi plot (no input required, based on user input)
total_height = (figure_height*(size-1))
figure_size_single_plot = (figure_width, figure_height)
figure_size_multi_plot = (figure_width, total_height)

# Grabs the size of the list
size = len(mode)
# Creates empty arrays for the x y data to live in
x_dir = []
y_dir_raw = []
y_max = []

# Loop through the mode and grab the TIC files. Save the x and y values to an
# array that can be accessed later.

for i in range(1,(size)):
        #print(n)
        file = mode[i]
        target = f"{data_dump}/{data}/{file}"
        #print(target)

        # Change directory to the appropriate parent file
        try:
            os.chdir(target)
        except:
            messagebox.showerror("error",err_msg_1)
        
        # Collect the TIC data
        df = pd.read_csv("tic_front.csv", header=2, names=["Time","Abund"])
        rows = df.shape[0]
        # Get x y values and store in a list
        x_temp = df["Time"]
        x_temp = x_temp.to_numpy()
        
        x_dir.append(x_temp)
        
        y_temp_raw = df["Abund"]
        y_temp_raw = y_temp_raw.to_numpy()      
        # Get and store max abundace for normalizing data
        y_temp_max = np.amax(y_temp_raw)
        
        y_dir_raw.append(y_temp_raw)
        y_max.append(y_temp_max)
        
# Grabs the max value of y to act as the nomalizer for absolute abundances        
normalizer = np.amax(y_max)
 
# Need to write two scripts to deal with the size-1 issue for the bottom graph x-axis
# A quick if check on the mode of operation and then same graph procedure just without/
# without the final x-axis plot
   
if mode == Single_File:
    x = x_dir[0]
    if relative == True and absolute == False:       
        y = (y_dir_raw[0]/y_max[0])*100
    elif absolute == True and relative == False:
        y = (y_dir_raw[0]/normalizer)*100
    elif relative == True and absolute == True or relative == False and absolute == False:
        print("Check relative and absolute True/Flase values")
        
    fig, ax = pyplot.subplots(1, figsize = figure_size_single_plot)
    fig.suptitle(graph_title, fontsize = graph_title_fontsize)
    
    subplot_title = f"{mode[1]}"
    ax.plot(x,y,
               linestyle = line_style,
               color = line_colour,
               linewidth = line_width)
    
    ax.set_ylim([y_axis_lower_limit,y_axis_upper_limit])
    ax.set_ylabel(y_axis_label, fontsize = y_axis_label_fontsize)
    # Checks for if you want to see the x-axis on all the plots or not
    if x_axis_numberline == True:
        ax.set_xlabel(x_axis_label, fontsize = x_axis_label_fontsize)
    else:
        ax.set_xticklabels(x_axis_tick_labels)
    ax.spines["top"].set_visible(False)
    ax.set_title(subplot_title, 
                x = subplot_title_x_position, 
                y = subplot_title_y_position, 
                pad = subplot_title_pad, 
                fontsize = subplot_title_fontsize)
    ax.tick_params(axis="both", which="major", labelsize = tick_label_fontsize)
 
    # Set tight figure layout
    fig.tight_layout()
    
    # Export plot as an SVG to the image dump
    os.chdir(code_dr)
    savefile = f"{graph_title}.svg"
    direct = f"{image_dump}/SVG/{savefile}"
    
    pyplot.savefig(direct, format="svg")
    
    # Export plot as an JPEG to the image dump
    os.chdir(code_dr)
    savefile = f"{graph_title}.jpg"
    direct = f"{image_dump}/JPEG/{savefile}"
    
    pyplot.savefig(direct, format="jpg")
    
    
    pyplot.show()
    
else: 

    # Loop through the x/y arrays, remember that size -2 is due to needing separate
    # formating for the bottom x axis and due to the data list having the first line
    # occupied by the graph title.
    
    fig, ax = pyplot.subplots((size-1), figsize = figure_size_multi_plot)
    fig.suptitle(graph_title, 
                 fontsize = graph_title_fontsize, 
                 y = graph_title_y_position)

        
    for i in range(0,(size-2)):
        # Grab the x and y values
        x = x_dir[i]
        if relative == True and absolute == False:       
            y = (y_dir_raw[i]/y_max[i])*100
        elif absolute == True and relative == False:
            y = (y_dir_raw[i]/normalizer)*100
        elif relative == True and absolute == True or relative == False and absolute == False:
            print("Check relative and absolute True/Flase values")
            
        subplot_title = f"{mode[i+1]}"
        ax[i].plot(x,y,
                   linestyle = line_style,
                   color = line_colour,
                   linewidth = line_width)
        
        ax[i].set_ylim([y_axis_lower_limit,y_axis_upper_limit])
        # Checks for if you want to see the x-axis on all the plots or not
        if x_axis_numberline == True:
            ax[i].set_xlabel(x_axis_label, fontsize = x_axis_label_fontsize)
        else:
            ax[i].set_xticklabels(x_axis_tick_labels)       
        ax[i].spines["bottom"].set_visible(False)
        ax[i].spines["top"].set_visible(False)
        ax[i].set_title(subplot_title, 
                    x = subplot_title_x_position, 
                    y = subplot_title_y_position, 
                    pad = subplot_title_pad, 
                    fontsize = subplot_title_fontsize)
        ax[i].tick_params(axis="y", which="major", labelsize=20)
        
    
    
    # Final loop to sort out the final graph with custom x-axis
    index = size-2
    axis_index = index
    
    #Sort out y-axis Labelling
    half = int(round(index/2,0))
    ax[half].set_ylabel(y_axis_label, fontsize = y_axis_label_fontsize)
    
    # Finish up with the final subplot
    x = x_dir[axis_index]
    
    if relative == True and absolute == False:       
        y = (y_dir_raw[axis_index]/y_max[axis_index])*100
    elif absolute == True and relative == False:
        y = (y_dir_raw[axis_index]/normalizer)*100
    elif relative == True and absolute == True or relative == False and absolute == False:
        print("Check relative and absolute True/Flase values")
        
    subplot_title = f"{mode[size-1]}"
    ax[index].plot(x,y,
               linestyle = line_style,
               color = line_colour,
               linewidth = line_width)
    
    ax[index].set_ylim([y_axis_lower_limit,y_axis_upper_limit])
    ax[index].set_xlabel(x_axis_label, fontsize = x_axis_label_fontsize)
    ax[index].spines["top"].set_visible(False)
    ax[index].set_title(subplot_title, 
                x = subplot_title_x_position, 
                y = subplot_title_y_position, 
                pad = subplot_title_pad, 
                fontsize = subplot_title_fontsize)
    ax[index].tick_params(axis="both", which="major", labelsize=20)
    
    # Set tight figure layout
    fig.tight_layout()
    
    # Export plot as an SVG to the image dump
    os.chdir(code_dr)
    savefile = f"{graph_title}.svg"
    direct = f"{image_dump}/SVG/{savefile}"
    
    pyplot.savefig(direct, format="svg")
    
    # Export plot as an JPEG to the image dump
    os.chdir(code_dr)
    savefile = f"{graph_title}.jpg"
    direct = f"{image_dump}/JPEG/{savefile}"
    
    pyplot.savefig(direct, format="jpg")
    
    
    pyplot.show()

print("Ta Da!")
